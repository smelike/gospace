import sys

from lhand import Lhand
from kpr import kpr

class Dws:

    def __init__(self):
    
        pass
    
    def run(self):
        pass
        # 当光耦1 遮挡时，开始获取称重的数据

        # 当光耦2 遮挡结束后，结束获取称重的数据


    # 光耦#1
    # 高光幕

    # 测量重量
    # 长宽光幕

    # 光耦#2
    